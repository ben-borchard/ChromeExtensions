$(document).keyup(function (event){
	console.log("cu");
});
